# AGENTS.md — Projeto 2 | Sprint 2

## Contexto do projeto

Disciplina: Estatística e Análise de Dados — 2º semestre de 2026.
Tema: tempo de carregamento de caminhões com grãos.
Objetivo do estudo: investigar se a padronização da preparação do carregamento (checklist de disponibilidade de grãos, equipamentos e equipe, além da organização prévia da sequência de atendimento) está associada à redução do tempo de carregamento.

A Sprint 2 dá continuidade à Sprint 1 e exige dois testes de hipóteses: um para a média e outro para a proporção. A média da Planilha 1 é a referência para o teste da média. Para o teste da proporção, as orientações determinam usar a proporção populacional de referência definida pela Questão 5 da Sprint 1 (Planilha 1) e comparar com a proporção amostral obtida na Questão 7.4(b) (Planilha 2).

## Estrutura do repositório

- `docs/`: orientações da Sprint 2, materiais de aula, relatório da Sprint 1 e rubrica.
- `dados/`: planilhas originais antes e depois da intervenção.
- `notebooks/`: notebooks originais da Sprint 1, preservados como referência.
- `notebooks/sprint-2/`: destino sugerido para os notebooks novos exigidos na Sprint 2.
- `resultados/`: destino sugerido para gráficos, tabelas e síntese dos testes.

## Resultados de referência da Sprint 1

Conforme o relatório final da Sprint 1:

- Planilha 1 (antes): 300 observações; média = 31,8867 minutos; desvio-padrão amostral = 3,8181 minutos.
- Planilha 2 (depois): 100 observações; média = 29,3100 minutos; desvio-padrão amostral = 3,8184 minutos.
- Para a faixa-alvo [20, 30] minutos: antes, 97/300 = 32,33%; depois, 57/100 = 57,00%.
- Na Questão 5 da Sprint 1 foi usado o intervalo [20, 43] minutos para a probabilidade baseada no modelo normal anterior à intervenção.
- A Sprint 1 descreveu a intervenção como padronização da preparação do carregamento e organização prévia do atendimento. Confirmar que essa descrição corresponde ao que o grupo efetivamente realizou.

Esses números são resultados descritivos da Sprint 1 e não devem ser apresentados como prova inferencial da eficácia.

## Requisitos da Sprint 2

Consultar `docs/orientacoes-sprint-2.pdf` antes de implementar ou redigir conclusões.

1. **Questão 1:** resumir situação, problema, objetivo e intervenção (Questão 7.1 da Sprint 1); apresentar e comparar média e proporção antes/depois; comentar indícios preliminares.
2. **Questão 2 — média:** formular H0 e H1 usando como valor de referência a média da Planilha 1; realizar o teste para α = 1% e α = 5%; apresentar valores críticos, regiões de rejeição e não rejeição, estatística z, gráficos em Python, decisão e conclusão contextualizada; comparar com a análise preliminar da Questão 1.
3. **Questão 3 — proporção:** respeitar a observação das orientações: p de referência deve ser a probabilidade no intervalo [a,b] da Questão 5 da Sprint 1 (Planilha 1), e p̂ deve ser o valor amostral calculado na Questão 7.4(b) (Planilha 2). Formular H0 e H1; realizar o teste para α = 1% e α = 5%; apresentar valores críticos, regiões, z, gráficos em Python, decisões e conclusões; comparar com a Questão 1.
4. Entregar os notebooks Python com os gráficos solicitados nos itens 2b e 3b. As orientações informam que os notebooks são pré-requisito para a correção dessas partes.
5. Consultar a rubrica completa no ambiente da disciplina; a imagem `docs/rubrica.png` é a referência fornecida neste conjunto de arquivos.

## Convenções estatísticas e de implementação

- Não alterar os arquivos de dados originais.
- Explicitar população, amostra, parâmetro, estimador, hipóteses, nível de significância, valor crítico, região crítica, estatística de teste e decisão.
- A hipótese nula deve conter igualdade. A alternativa deve refletir a pergunta de pesquisa e ser definida antes do cálculo.
- O relatório da Sprint 1 aponta uma expectativa direcional de redução da média. A direção do teste deve ser justificada e validada com o enunciado/objetivo da investigação, não escolhida em função do resultado observado.
- Para a média, seguir a formulação e as condições da aula de testes de hipótese. A aula apresenta `z = (x̄ - μ0)/(σ/√n)` quando o desvio-padrão populacional é conhecido. Não substituir silenciosamente σ por desvio-padrão amostral: verificar com o professor/material se σ populacional é de fato conhecido ou se é necessário outro procedimento.
- Para proporção, a aula apresenta `z = (p̂ - p0)/√(p0(1-p0)/n)`. Verificar a condição de aproximação normal e deixar claro qual proporção está sendo testada.
- Distinguir “não rejeitar H0” de “aceitar/provar H0”. Não afirmar que uma intervenção causou a mudança apenas pela comparação antes/depois.
- Manter unidades em minutos e proporções em escala consistente (0–1 ou %).
- Usar sementes apenas quando houver aleatoriedade computacional; registrar versões e caminhos relativos dos arquivos.
- Preferir Python com pandas, numpy, scipy e matplotlib. Os gráficos devem indicar distribuição, valores críticos, região(ões) crítica(s) e z calculado.

## Próximos passos recomendados

1. Confirmar a intervenção realmente executada e validar a pergunta de pesquisa com os critérios da Sprint 1.
2. Recalcular a probabilidade p0 para o intervalo escolhido na Questão 5 a partir dos dados e parâmetros da Planilha 1, conforme a definição das orientações; não confundir esse p0 com a proporção empírica no intervalo [20,30].
3. Confirmar p̂ da Questão 7.4(b) com a Planilha 2 e documentar claramente o intervalo usado. O relatório da Sprint 1 registra 57/100 = 0,57 para [20,30]; conferir a correspondência exata com a Questão 5 e a correção da Sprint 1 antes de usar no teste.
4. Criar um notebook separado para o teste da média e outro para o teste da proporção, com cálculos reproduzíveis e gráficos.
5. Redigir as decisões para α = 0,01 e α = 0,05 e comparar com os indícios descritivos da Questão 1.
6. Atualizar o relatório final, conferir a rubrica e executar os notebooks do início ao fim antes da entrega.

## Instruções para agentes e colaboradores

- Leia este arquivo e `docs/orientacoes-sprint-2.pdf` antes de fazer alterações.
- Use os arquivos em `docs/` como fonte dos requisitos e os arquivos em `dados/` como fontes primárias dos dados.
- Preserve os arquivos originais; produza novos notebooks e relatórios em pastas próprias.
- Não invente resultados, valores de σ populacional, justificativas operacionais ou detalhes da intervenção ausentes das fontes.
- Registre hipóteses de trabalho e qualquer divergência entre planilhas, notebooks, relatório e orientações.
- Ao concluir uma etapa, informe arquivos alterados, método adotado, resultados principais, limitações e validações pendentes.
