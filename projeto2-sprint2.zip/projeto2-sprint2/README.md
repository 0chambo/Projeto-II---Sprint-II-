# Projeto 2 — Sprint 2

Repositório de trabalho da Sprint 2 da disciplina Estatística e Análise de Dados (2º semestre de 2026).

## Conteúdo

- `AGENTS.md`: contexto do projeto, requisitos, convenções e roteiro de execução.
- `docs/`: orientações, aulas, relatório da Sprint 1 e rubrica.
- `dados/`: planilhas originais anteriores e posteriores à intervenção.
- `notebooks/`: notebooks da Sprint 1 preservados como referência.
- `notebooks/sprint-2/`: local para os notebooks de teste de hipótese da Sprint 2.
- `resultados/`: local para gráficos e resultados exportados.

## Comece por aqui

1. Leia `AGENTS.md`.
2. Leia `docs/orientacoes-sprint-2.pdf` e confira `docs/rubrica.png`.
3. Reexecute os notebooks da Sprint 1 para validar os números-base.
4. Desenvolva os testes da média e da proporção em notebooks separados dentro de `notebooks/sprint-2/`.

Os resultados descritivos da Sprint 1 não substituem os testes inferenciais solicitados nesta Sprint.
